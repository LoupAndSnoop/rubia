--Makes a list at data/control stages to know which machines to look for, consistently.
local machine_upgrade_list = {}


--Machine upgrade lists
machine_upgrade_list = {
    {handler = "RMU-recyclers", effects = {speed = 0.25}, machines = {"recycler", }}

--"recycling"
--"crushing"
}
