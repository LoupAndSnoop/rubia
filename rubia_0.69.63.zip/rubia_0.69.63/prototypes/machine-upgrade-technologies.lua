if not mods["machine-upgrades"] then return end

--Machine-upgrades specific technologies



