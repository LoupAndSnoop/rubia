require("__rubia__.prototypes.data-script.crapapult-recipes")
require("__rubia__.prototypes.data-script.rubia-surface-blacklist")
require("__rubia__.prototypes.technology-final-fixes")
require("__rubia__.compat.distant-misfires")

--log(serpent.block(data.raw.planet.nauvis.map_gen_settings.autoplace_settings.entity.settings))

--These lines are exclusively for debugging noise expressions. Do not delete.
--require("__rubia__/prototypes/planet/noise-expression-tests")
--noise_debug.apply_controls()