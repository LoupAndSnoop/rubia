
data:extend({
--[[    {
        type = "item-group",
        name = "sulfur-intermediates",
        order = "fz",
        icon = "__base__/graphics/icons/sulfur.png",
        icon_size = 128,
      }]]
      {
        type = "item-subgroup",
        name = "rubia-biorecycling",
        group = "intermediate-products",
        order = "o-a",
      },
      --[[{
        type = "item-subgroup",
        name = "rubia-science-recipes",
        group = "intermediate-products",
        order = "o-b",
      },]]
      {
        type = "item-subgroup",
        name = "rubia-compat-recipes",
        group = "intermediate-products",
        order = "o-f",
      },
})
