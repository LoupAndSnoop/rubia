local constants = {}

--constants.DISABLE_TECH_HIDING = false
constants.RUBIA_AUTO_ENTITY_PREFIX = "rubia-auto-variant-"
constants.WARNING_PRINT_SETTINGS = {color={r=0.9,g=0,b=0,a=1}}
constants.GREEN_PRINT_SETTINGS = {color={r=0.2,g=1,b=0.2,a=1}}

return constants